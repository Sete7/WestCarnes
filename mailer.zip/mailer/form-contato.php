<?php

require_once('class.phpmailer.php');



$nome = utf8_decode(strip_tags(trim($_POST['txtnome'])));
$email = utf8_decode(strip_tags(trim($_POST['txtemail'])));
$telefone = utf8_decode(strip_tags(trim($_POST['txtfone'])));
$msg = utf8_decode(strip_tags(trim($_POST['txtmsg'])));

//monta Mensagem
$mensagem = "Nome: " . $nome . "<br/>";
$mensagem .= "E-mail: " . $email . "<br/>";
$mensagem .= "Interesse: " . $telefone . "<br/>";
$mensagem .= "Mensagem: " . $msg . "<br/>";

//cabeçalho para formulario

$headers = "MIME-Version: 1.0\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\n";
$headers .= "From: contato@westcarnes.com.br\n";
//$headers .= "From: telmoricardorosa@gmail.com\n";
//$headers .= 'Cc: telmoricardorosa@gmail.com' . "\r\n";
//$headers .= 'Cc: bodynho3@gmail.com' . "\r\n";
//$headers .= 'Bcc: birthdaycheck@example.com' . "\r\n";


if (mail("contato@westcarnes.com.br", 'Site West Carnes', $mensagem, $headers)) {
    echo "<script>alert('Mensagem enviada com sucesso! ')</script>";
    $insertGoTo = 'index';
    header("refresh:1;url={$insertGoTo}");
} else {
    echo "A mensagem não pode ser enviada!";
}
