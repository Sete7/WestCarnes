<?php

echo "<h1>Página 404 Erro ao encontrar a Página.</h1>";