<main class="main_receita container">
    <section class="sec_receita">
        <h1 class="font-zero">Queremos te ouvir</h1>
        <article class="box-receita">
            <h1 class="font-zero">Formulário West Carnes</h1>
            <div class="content">
                <div class="desc_receita">
                    <h1>RECEITAS PARA SEU DIA</h1> 
                </div>



            </div>
            <div class="box-receita container">
                <div class="book-receita">
                    <img src="<?= REQUIRE_PATH; ?>/img/livro2.png" alt=""/>
                    <div class="lista-receitas">
                         <h1>Carne Bovina</h1> 
                        <ul>
                             <li>
                                <a href="<?= HOME; ?>/single-receita">Almôndegas recheadas com queijo</a>
                            </li>
                            <li>
                                <a href="<?= HOME; ?>/single-receita">Salada de alcatras</a>
                            </li>                           
                            <li>
                                <a href="<?= HOME; ?>/single-receita">Contrafilé a new york</a>
                            </li>                          
                        </ul>
                    </div>
                </div>
            </div>
        </article>
    </section>
</main>

